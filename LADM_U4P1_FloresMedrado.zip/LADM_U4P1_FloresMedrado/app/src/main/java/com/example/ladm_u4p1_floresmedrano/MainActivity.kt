package com.example.ladm_u4p1_floresmedrano

import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    var baseRemota = FirebaseFirestore.getInstance()
    var idMensaje = ""
    var msgAceptado = ""
    var msgNoAceptado = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if(ActivityCompat.checkSelfPermission(this,android.Manifest.permission.SEND_SMS)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,arrayOf(android.Manifest.permission.SEND_SMS),1)
        }
        if (ActivityCompat.checkSelfPermission(this,android.Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,arrayOf(android.Manifest.permission.READ_CALL_LOG),2)
        }
        if (ActivityCompat.checkSelfPermission(this,android.Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,arrayOf(android.Manifest.permission.CALL_PHONE),3)
        }
        if (ActivityCompat.checkSelfPermission(this,android.Manifest.permission.PROCESS_OUTGOING_CALLS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,arrayOf(android.Manifest.permission.PROCESS_OUTGOING_CALLS),4)
        }
        if (ActivityCompat.checkSelfPermission(this,android.Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,arrayOf(android.Manifest.permission.READ_PHONE_STATE),5)
        }
        cargar()

        botonContactos.setOnClickListener {
            var ventanaContactos = Intent(this, Contactos::class.java)
            startActivity(ventanaContactos)
        }

        botonGuardarMensajes.setOnClickListener {
            guardar()
        }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode == 1){
            Toast.makeText(this,"Se otorgó el permiso de envio de mensajes",Toast.LENGTH_LONG).show()
        }
        if(requestCode == 2){
            Toast.makeText(this,"Se otorgó el permiso READ_CALL_LOG",Toast.LENGTH_LONG).show()
        }

        if(requestCode == 3){
            Toast.makeText(this,"Se otorgó el permiso CALL_PHONE",Toast.LENGTH_LONG).show()
        }
        if(requestCode == 4){
            Toast.makeText(this,"Se otorgó el permiso PROCESS_OUTGOING_CALLS",Toast.LENGTH_LONG).show()
        }
        if(requestCode == 5){
            Toast.makeText(this,"Se otorgó el permiso READ_PHONE_STATE",Toast.LENGTH_LONG).show()
        }
    }
    private fun cargar(){

        baseRemota.collection("Mensajes")
            .addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                if(firebaseFirestoreException!=null){
                    Toast.makeText(this,"Error, fallo en conexión",Toast.LENGTH_LONG).show()
                    return@addSnapshotListener
                }
                for(document in querySnapshot!!){
                    msgAceptado = document.getString("deseado").toString()
                    msgNoAceptado = document.getString("noDeseado").toString()
                    idMensaje = document.id
                }
                msgAcept.setText(msgAceptado)
                msgDeny.setText(msgNoAceptado)
            }
    }
    private fun guardar() {
        if(msgAcept.text.isEmpty()||msgDeny.text.isEmpty()){
            AlertDialog.Builder(this).setTitle("ATENCION").setMessage("Por favor introduzca los mensajes").show()
        }else{
            baseRemota.collection("Mensajes")
                    .document(idMensaje)
                    .update("deseado",msgAcept.text.toString(),
                            "noDeseado",msgDeny.text.toString())
                    .addOnSuccessListener {
                        Toast.makeText(this,"Mensajes Guardado", Toast.LENGTH_LONG).show()
                    }
                    .addOnFailureListener {
                        Toast.makeText(this,"Error, fallo al guardar", Toast.LENGTH_LONG).show()
                    }
        }

    }
}

package com.example.ladm_u4p1_floresmedrano

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_main2.*

class Contactos : AppCompatActivity() {
    var baseRemota = FirebaseFirestore.getInstance()
    var dataLista = ArrayList<String>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        botonAlmacenar.setOnClickListener {
            if(txtNombre.text.isEmpty() || txtNumero.text.isEmpty()){
                AlertDialog.Builder(this).setTitle("ATENCION").setMessage("Es necesario llenar todos los campos").show()
            }else {
                insertar()
            }
        }
        botonAtras.setOnClickListener {
            finish()
        }
        cargarLista()
    }
    private fun cargarLista(){
        dataLista.clear()
        baseRemota.collection("contactos")
            .addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                if(firebaseFirestoreException!=null){
                    Toast.makeText(this,"Error, fallo en conexión",Toast.LENGTH_LONG).show()
                    return@addSnapshotListener
                }
                for(document in querySnapshot!!){
                    var cadena = "Nombre: "+document.getString("nombre")+"\nNúmero: "+document.getString("numero")+"\nDeseado: "+document.getBoolean("deseado")
                    dataLista.add(cadena)
                }
                if(dataLista.size ==0){
                    dataLista.add("Cantidad de registros : 0")
                }
                var adaptador = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,dataLista)
                contactos.adapter = adaptador
            }
    }

    private fun insertar(){
        dataLista.clear()
            var datosInsertar = hashMapOf(
                "numero" to txtNumero.text.toString(),
                "nombre" to txtNombre.text.toString(),
                "deseado" to checkDeseado.isChecked
            )
            baseRemota.collection("contactos")
                .add(datosInsertar as Any)
                .addOnSuccessListener {
                    Toast.makeText(this, "Contacto ${txtNombre.text} registrado", Toast.LENGTH_LONG).show()
                    cargarLista()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Fallo al insertar", Toast.LENGTH_LONG).show()
                }
    }
}
